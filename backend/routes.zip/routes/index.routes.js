const express = require("express");
const routes = express.Router();
const shop_detail = require("./shop_detail/index.shop_detail");
const customer_details = require("./customer_detail/index.customer_details");

routes.get("/", (req, res) => {
  res.status(200).send("Hello! Api is working fine...");
});

routes.use("/", shop_detail);
routes.use("/", customer_details);

module.exports = routes;
